#include <windows.h>
#include <iostream>
#include <vector>
#include <conio.h>
#include <fstream>
#include <string>
#include <algorithm>
#include <iomanip>
#include <ctime>

const int WIDTH = 40, HEIGHT = 20;
const char WALL = '#', SNAKE = 'O', FOOD = '@', EMPTY = '.', ENEMY = 'X', COLLECTIBLE = '*';

struct Position {
    int x, y;
    bool operator==(const Position& other) const { return x == other.x && y == other.y; }
};

enum GameState { MENU, PLAYING, GAME_OVER };

class Entity {
protected:
    Position pos;
    char symbol;
public:
    Entity(Position p, char s) : pos(p), symbol(s) {}
    virtual void Update() = 0;
    Position GetPosition() const { return pos; }
    char GetSymbol() const { return symbol; }
};

class Enemy : public Entity {
public:
    Enemy(Position p) : Entity(p, ENEMY) {}
    void Update() override {
        if (rand() % 5 == 0) {
            static const int dx[] = {1, -1, 0, 0};
            static const int dy[] = {0, 0, 1, -1};
            int dir = rand() % 4;
            int newX = pos.x + dx[dir], newY = pos.y + dy[dir];
            if (newX > 0 && newX < WIDTH-1 && newY > 0 && newY < HEIGHT-1) {
                pos.x = newX;
                pos.y = newY;
            }
        }
    }
};

class Game {
private:
    std::vector<Position> snake;
    std::vector<Enemy> enemies;
    std::vector<Position> collectibles;
    Position food;
    int dx = 1, dy = 0, score = 0, level = 1, moves = 0;
    bool gameOver = false;
    GameState state = MENU;
    std::vector<std::vector<char>> map;
    const int COLORS[6] = {11, 10, 12, 8, 13, 14}; // MENU, SNAKE, FOOD, WALL, ENEMY, COLLECT

    void SetColor(int color) { SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color); }
    void ResetColor() { SetColor(7); }
    void SetCursorPosition(int x, int y) {
        COORD coord{static_cast<SHORT>(x), static_cast<SHORT>(y)};
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    }

    Position GetRandomPosition() {
        Position pos;
        do {
            pos.x = rand() % (WIDTH - 2) + 1;
            pos.y = rand() % (HEIGHT - 2) + 1;
        } while (map[pos.y][pos.x] != EMPTY);
        return pos;
    }

    void SpawnFood() {
        food = GetRandomPosition();
        map[food.y][food.x] = FOOD;
    }

    void SpawnCollectible() {
        Position pos = GetRandomPosition();
        collectibles.push_back(pos);
        map[pos.y][pos.x] = COLLECTIBLE;
    }

    void LoadLevel(int lvl) {
        InitializeMap();
        std::string filename = "level" + std::to_string(lvl) + ".txt";
        std::ifstream levelFile(filename);
        if (levelFile.is_open()) {
            std::string line;
            int y = 0;
            while (getline(levelFile, line) && y < HEIGHT) {
                for (int x = 0; x < std::min((int)line.length(), WIDTH); x++) {
                    if (line[x] == WALL) map[y][x] = WALL;
                }
                y++;
            }
            levelFile.close();
        }

        enemies.clear();
        collectibles.clear();
        for (int i = 0; i < (lvl * 2); i++) {
            enemies.push_back(Enemy(GetRandomPosition()));
        }
        SpawnFood();
        SpawnCollectible();
    }

    void InitializeMap() {
        map = std::vector<std::vector<char>>(HEIGHT, std::vector<char>(WIDTH, EMPTY));
        for (int i = 0; i < WIDTH; i++) {
            map[0][i] = map[HEIGHT-1][i] = WALL;
        }
        for (int i = 0; i < HEIGHT; i++) {
            map[i][0] = map[i][WIDTH-1] = WALL;
        }
    }

public:
    Game() {
        InitializeMap();
        snake.push_back({WIDTH/2, HEIGHT/2});
        SpawnFood();
        SpawnCollectible();
        CONSOLE_CURSOR_INFO info{100, FALSE};
        SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &info);
    }

    void HandleInput() {
        if (_kbhit()) {
            char key = _getch();
            if (key == 27) {
                if (state == PLAYING) { state = MENU; Reset(); }
                else gameOver = true;
                return;
            }
            switch (state) {
                case MENU:
                    if (key >= '1' && key <= '3') {
                        level = key - '0';
                        LoadLevel(level);
                        state = PLAYING;
                    }
                    break;
                case PLAYING:
                    switch (key) {
                        case 'w': if (dy != 1) { dx = 0; dy = -1; moves++; } break;
                        case 's': if (dy != -1) { dx = 0; dy = 1; moves++; } break;
                        case 'a': if (dx != 1) { dx = -1; dy = 0; moves++; } break;
                        case 'd': if (dx != -1) { dx = 1; dy = 0; moves++; } break;
                    }
                    break;
                case GAME_OVER:
                    if (key == 'r' || key == 'R') {
                        Reset();
                        state = MENU;
                    }
                    break;
            }
        }
    }

    void Update() {
        if (state != PLAYING) return;

        Position newHead = {snake[0].x + dx, snake[0].y + dy};
        if (map[newHead.y][newHead.x] == WALL || map[newHead.y][newHead.x] == SNAKE) {
            state = GAME_OVER;
            return;
        }

        if (newHead == food) {
            score += 10;
            SpawnFood();
        } else {
            Position tail = snake.back();
            map[tail.y][tail.x] = EMPTY;
            snake.pop_back();
        }

        for (auto it = collectibles.begin(); it != collectibles.end(); ) {
            if (newHead == *it) {
                score += 20;
                it = collectibles.erase(it);
                SpawnCollectible();
            } else ++it;
        }

        for (auto& enemy : enemies) {
            enemy.Update();
            if (enemy.GetPosition() == newHead) {
                state = GAME_OVER;
                return;
            }
        }

        snake.insert(snake.begin(), newHead);
        map[newHead.y][newHead.x] = SNAKE;

        if (score >= level * 100 && level < 3) {
            level++;
            LoadLevel(level);
        }
    }

    void Draw() {
        SetCursorPosition(0, 0);
        switch (state) {
            case MENU:
                SetColor(COLORS[0]);
                std::cout << "\n\n    ##################################\n"
                         << "    #           SNAKE GAME           #\n"
                         << "    ##################################\n\n"
                         << "       Select Level (1-3):\n\n"
                         << "       1. Easy   - Basic Maze\n"
                         << "       2. Medium - More Walls + Enemies\n"
                         << "       3. Hard   - Complex Maze + Fast\n\n"
                         << "    ##################################\n"
                         << "    # Controls:                      #\n"
                         << "    # WASD  - Move                   #\n"
                         << "    # ESC   - Exit                   #\n"
                         << "    ##################################\n";
                break;

            case PLAYING:
            case GAME_OVER:
                SetColor(COLORS[0]);
                std::cout << "##################################\n"
                         << "# Score: " << std::setw(5) << score
                         << " Level: " << level
                         << " Moves: " << std::setw(5) << moves << " #\n"
                         << "##################################\n";

                for (int y = 0; y < HEIGHT; y++) {
                    std::cout << " ";
                    for (int x = 0; x < WIDTH; x++) {
                        char display = map[y][x];
                        switch (display) {
                            case WALL: SetColor(COLORS[3]); break;
                            case SNAKE: SetColor(COLORS[1]); break;
                            case FOOD: SetColor(COLORS[2]); break;
                            case COLLECTIBLE: SetColor(COLORS[5]); break;
                            default: SetColor(7); break;
                        }
                        
                        for (const auto& enemy : enemies) {
                            if (enemy.GetPosition().x == x && enemy.GetPosition().y == y) {
                                SetColor(COLORS[4]);
                                display = ENEMY;
                            }
                        }
                        std::cout << display << ' ';
                    }
                    std::cout << '\n';
                }

                if (state == GAME_OVER) {
                    SetColor(COLORS[2]);
                    std::cout << "\n    === GAME OVER! ===\n"
                             << "    Final Score: " << score << "\n"
                             << "    Press 'R' to restart or ESC to exit\n";
                }
                break;
        }
        ResetColor();
    }

    void Reset() {
        snake.clear();
        enemies.clear();
        collectibles.clear();
        score = moves = 0;
        dx = 1;
        dy = 0;
        gameOver = false;
        state = MENU;
        InitializeMap();
        snake.push_back({WIDTH/2, HEIGHT/2});
        SpawnFood();
        SpawnCollectible();
    }

    void Run() {
        while (!gameOver) {
            HandleInput();
            Update();
            Draw();
            Sleep(100 / level);
        }
    }
};

int main() {
    srand(time(0));
    Game game;
    game.Run();
    return 0;
}