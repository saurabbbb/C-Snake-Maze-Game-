#include <windows.h>
#include <iostream>
#include <vector>
#include <conio.h>
#include <fstream>
#include <string>
#include <algorithm>
#include <iomanip>
#include <ctime>
#include <limits> 

const int WIDTH = 40;
const int HEIGHT = 20;
const char WALL = '#';
const char SNAKE = 'O';
const char FOOD = '@';
const char EMPTY = '.';
const char ENEMY = 'X';
const char COLLECTIBLE = '*';

struct Position {
    int x, y;
    bool operator==(const Position& other) const {
        return x == other.x && y == other.y;
    }
};

const std::vector<std::vector<Position>> LEVEL_OBSTACLES = {
    // Level 1 - Basic
    {
        {10, 5}, {11, 5}, {12, 5},
        {28, 15}, {29, 15}, {30, 15}
    },
    // Level 2 - Medium
    {
        {8, 5}, {9, 5}, {10, 5}, {11, 5},
        {28, 8}, {29, 8}, {30, 8}, {31, 8},
        {15, 12}, {16, 12}, {17, 12}, {18, 12}
    },
    // Level 3 - Hard
    {
        {8, 5}, {9, 5}, {10, 5}, {11, 5}, {12, 5},
        {28, 8}, {29, 8}, {30, 8}, {31, 8}, {32, 8},
        {15, 12}, {16, 12}, {17, 12}, {18, 12}, {19, 12},
        {8, 15}, {9, 15}, {10, 15}, {11, 15}, {12, 15}
    }
};

enum GameState {
    MENU,
    PLAYING,
    GAME_OVER
};

class Entity {
protected:
    Position pos;
    char symbol;

public:
    Entity(Position p, char s) : pos(p), symbol(s) {}
    virtual void Update() = 0;
    Position GetPosition() const { return pos; }
    char GetSymbol() const { return symbol; }
};

class Enemy : public Entity {
private:
    int moveCounter = 0;

public:
    Enemy(Position p) : Entity(p, ENEMY) {}
    void Update() override {
        moveCounter++;
        if (moveCounter >= 5) {
            moveCounter = 0;
            int dir = rand() % 4;
            switch (dir) {
                case 0: if (pos.x < WIDTH-2) pos.x++; break;
                case 1: if (pos.x > 1) pos.x--; break;
                case 2: if (pos.y < HEIGHT-2) pos.y++; break;
                case 3: if (pos.y > 1) pos.y--; break;
            }
        }
    }
};

class Game {
private:
    std::vector<Position> snake;
    std::vector<Enemy> enemies;
    std::vector<Position> collectibles;
    Position food;
    int dx = 1, dy = 0;
    bool gameOver = false;
    int score = 0;
    int level = 1;
    int moves = 0;
    GameState state = MENU;
    std::vector<std::vector<char>> map;
    const int MENU_COLOR = 11;
    const int SNAKE_COLOR = 10;
    const int FOOD_COLOR = 12;
    const int WALL_COLOR = 8;
    const int ENEMY_COLOR = 13;
    const int COLLECT_COLOR = 14;

    void SetColor(int color) {
        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);
    }

    void ResetColor() {
        SetColor(7);
    }

    void SetCursorPosition(int x, int y) {
        COORD coord;
        coord.X = x;
        coord.Y = y;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    }

    void HideCursor() {
        CONSOLE_CURSOR_INFO info;
        info.dwSize = 100;
        info.bVisible = FALSE;
        SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &info);
    }

    void DrawMenu() {
        system("cls");
        SetColor(MENU_COLOR);
        std::cout << "\n\n";
        std::cout << "    ##################################\n";
        std::cout << "    #           SNAKE GAME           #\n";
        std::cout << "    ##################################\n\n";
        
        std::cout << "       Select Level (1-3):\n\n";
        std::cout << "       1. Easy   - Basic Maze\n";
        std::cout << "       2. Medium - More Walls + Enemies\n";
        std::cout << "       3. Hard   - Complex Maze + Fast\n\n";
        
        std::cout << "    ##################################\n";
        std::cout << "    # Controls:                      #\n";
        std::cout << "    # WASD  - Move                   #\n";
        std::cout << "    # ESC   - Exit                   #\n";
        std::cout << "    ##################################\n";

        std::ifstream scoreFile("highscores.txt");
        if (scoreFile) {
            std::cout << "\n    === High Scores ===\n";
            std::string name;
            int playerScore;
            int count = 0;
            while (scoreFile >> name >> playerScore && count < 5) {
                std::cout << "    " << std::setw(10) << std::left << name 
                         << ": " << playerScore << "\n";
                count++;
            }
        }
        ResetColor();
    }

    void SpawnFood() {
        do {
            food.x = rand() % (WIDTH - 2) + 1;
            food.y = rand() % (HEIGHT - 2) + 1;
        } while (map[food.y][food.x] != EMPTY);
        map[food.y][food.x] = FOOD;
    }

    void SpawnCollectible() {
        Position pos;
        do {
            pos.x = rand() % (WIDTH - 2) + 1;
            pos.y = rand() % (HEIGHT - 2) + 1;
        } while (map[pos.y][pos.x] != EMPTY);
        collectibles.push_back(pos);
        map[pos.y][pos.x] = COLLECTIBLE;
    }

    void LoadLevel(int lvl) {
        InitializeMap();
        if (lvl >= 1 && lvl <= 3) {
            for (const auto& pos : LEVEL_OBSTACLES[lvl - 1]) {
                map[pos.y][pos.x] = WALL;
            }
        }

        enemies.clear();
        collectibles.clear();
        int enemyCount = (lvl == 1) ? 2 : (lvl == 2) ? 4 : 6;
        for (int i = 0; i < enemyCount; i++) {
            Position enemyPos;
            do {
                enemyPos.x = rand() % (WIDTH - 2) + 1;
                enemyPos.y = rand() % (HEIGHT - 2) + 1;
            } while (map[enemyPos.y][enemyPos.x] != EMPTY);
            enemies.push_back(Enemy(enemyPos));
        }
        SpawnFood();
        SpawnCollectible();
    }

    void InitializeMap() {
        map = std::vector<std::vector<char>>(HEIGHT, std::vector<char>(WIDTH, EMPTY));
        for (int i = 0; i < WIDTH; i++) {
            map[0][i] = WALL;
            map[HEIGHT-1][i] = WALL;
        }
        for (int i = 0; i < HEIGHT; i++) {
            map[i][0] = WALL;
            map[i][WIDTH-1] = WALL;
        }
    }

    void SaveHighScore() {
        std::string playerName;
        SetCursorPosition(0, HEIGHT + 5);
        std::cout << "Enter your name (max 10 chars): ";
        
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::getline(std::cin, playerName);
        playerName = playerName.substr(0, 10);

        std::vector<std::pair<int, std::string>> highScores;
        std::ifstream inFile("highscores.txt");
        std::string name;
        int oldScore;
        
        while (inFile >> name >> oldScore) {
            highScores.push_back({oldScore, name});
        }
        inFile.close();

        highScores.push_back({score, playerName});
        std::sort(highScores.begin(), highScores.end(), 
            [](const auto& a, const auto& b) { return a.first > b.first; });

        std::ofstream outFile("highscores.txt");
        for (size_t i = 0; i < std::min(size_t(5), highScores.size()); i++) {
            outFile << highScores[i].second << " " << highScores[i].first << "\n";
        }
    }

public:
    Game() {
        InitializeMap();
        snake.push_back({WIDTH/2, HEIGHT/2});
        SpawnFood();
        SpawnCollectible();
        HideCursor();
    }

    void HandleInput() {
        if (_kbhit()) {
            char key = _getch();
            switch (state) {
                case MENU:
                    if (key >= '1' && key <= '3') {
                        level = key - '0';
                        LoadLevel(level);
                        state = PLAYING;
                    }
                    if (key == 27) gameOver = true;
                    break;

                case PLAYING:
                    switch (key) {
                        case 'w': if (dy != 1) { dx = 0; dy = -1; moves++; } break;
                        case 's': if (dy != -1) { dx = 0; dy = 1; moves++; } break;
                        case 'a': if (dx != 1) { dx = -1; dy = 0; moves++; } break;
                        case 'd': if (dx != -1) { dx = 1; dy = 0; moves++; } break;
                        case 27: state = MENU; Reset(); break;
                    }
                    break;

                    case GAME_OVER:
                    if (key == 'r' || key == 'R') {  
                        Reset();
                        state = MENU;
                    }
                    if (key == 27) gameOver = true;
                    break;
            }
        }
    }

    void Update() {
        if (state != PLAYING) return;

        Position newHead = {snake[0].x + dx, snake[0].y + dy};

        if (map[newHead.y][newHead.x] == WALL || 
            map[newHead.y][newHead.x] == SNAKE) {
            state = GAME_OVER;
            return;
        }

        if (newHead == food) {
            score += 10;
            SpawnFood();
        } else {
            Position tail = snake.back();
            map[tail.y][tail.x] = EMPTY;
            snake.pop_back();
        }

        for (auto it = collectibles.begin(); it != collectibles.end(); ) {
            if (newHead == *it) {
                score += 20;
                it = collectibles.erase(it);
                SpawnCollectible();
            } else {
                ++it;
            }
        }

        for (auto& enemy : enemies) {
            enemy.Update();
            Position enemyPos = enemy.GetPosition();
            if (enemyPos == newHead) {
                state = GAME_OVER;
                return;
            }
        }

        snake.insert(snake.begin(), newHead);
        map[newHead.y][newHead.x] = SNAKE;

        if (score >= level * 100) {
            level++;
            if (level <= 3) {
                LoadLevel(level);
            } else {
                state = GAME_OVER;
            }
        }
    }

    void Draw() {
        SetCursorPosition(0, 0);
        switch (state) {
            case MENU:
                DrawMenu();
                break;

            case PLAYING:
            case GAME_OVER:
                SetColor(MENU_COLOR);
                std::cout << "##################################\n";
                std::cout << "# Score: " << std::setw(5) << score;
                std::cout << " Level: " << level;
                std::cout << " Moves: " << std::setw(5) << moves << " #\n";
                std::cout << "##################################\n";

                for (int y = 0; y < HEIGHT; y++) {
                    std::cout << " ";
                    for (int x = 0; x < WIDTH; x++) {
                        char display = map[y][x];
                        switch (display) {
                            case WALL: SetColor(WALL_COLOR); break;
                            case SNAKE: SetColor(SNAKE_COLOR); break;
                            case FOOD: SetColor(FOOD_COLOR); break;
                            case COLLECTIBLE: SetColor(COLLECT_COLOR); break;
                            default: SetColor(7); break;
                        }
                        
                        for (const auto& enemy : enemies) {
                            if (enemy.GetPosition().x == x && enemy.GetPosition().y == y) {
                                SetColor(ENEMY_COLOR);
                                display = ENEMY;
                            }
                        }
                        std::cout << display << ' ';
                    }
                    std::cout << "\n";
                }
                ResetColor();

                if (state == GAME_OVER) {
                    SetColor(FOOD_COLOR);
                    std::cout << "\n    === GAME OVER! ===\n";
                    std::cout << "    Final Score: " << score << "\n";
                    std::cout << "    Press 'R' to restart or ESC to exit\n";
                    SaveHighScore();
                }
                break;
        }
    }

    void Reset() {
        snake.clear();
        enemies.clear();
        collectibles.clear();
        score = 0;
        moves = 0;
        dx = 1;
        dy = 0;
        gameOver = false;  
        state = MENU;      
        InitializeMap();
        snake.push_back({WIDTH/2, HEIGHT/2});
        SpawnFood();
        SpawnCollectible();
    }

    void Run() {
        while (!gameOver) {
            HandleInput();
            Update();
            Draw();
            Sleep(100 / level);
        }
    }
};

int main() {
    srand(time(0));
    Game game;
    game.Run();
    return 0;
}